﻿namespace InvoiceManagement
{


    partial class PayablesDataSet
    {
    }
}

namespace InvoiceManagement.PayablesDataSetTableAdapters {
    
    
    public partial class VendorsTableAdapter {
    }
}
